#!/usr/bin/env python

import sys, socket, random, thread

HOST = sys.argv[1]
PORT = 2003
LISTEN_PORT = int(sys.argv[2])


def sendClientInfo():
    addr = socket.gethostbyname(socket.gethostname())
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((HOST, PORT))
    s.send('%s:%s\r\n' % (addr, LISTEN_PORT))


def Janken():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', LISTEN_PORT))
    s.listen(1)
    while True:
        conn, addr = s.accept()
        f = conn.makefile("r+b")
        data = f.readline()
        if data=='CALL\r\n':
            print 'CALLED'
            hand = random.choice(['PAPER', 'SCISSORS', 'ROCK'])
            conn.send(hand+'\r\n')


thread.start_new_thread(Janken, ())

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(('', LISTEN_PORT))

sendClientInfo()

while True:
    data = s.recv(1000)
    if data.startswith('100'):
        print 'Only one winner'
    elif data.startswith('110'):
        print 'win'
    elif data.startswith('120'):
        print 'lose'
    elif data.startswith('130'):
        print 'draw'
