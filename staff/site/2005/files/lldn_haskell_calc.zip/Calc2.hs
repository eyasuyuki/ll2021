import qualified Data.Set as Set
import qualified Data.Map as Map
import Data.Maybe (fromMaybe, fromJust)
import Data.List (find, unfoldr)
import Data.Char
import Control.Monad
import Prelude hiding (lex, exp, pred)

-- ---------------------------------------------------------------------------
-- Operator

infixl 9 <@>

(<@>) :: Term -> Term -> Term
(<@>) = App

-- ---------------------------------------------------------------------------
-- Term

type Var = String

data Term
    = Var Var
    | Lam Var Term
    | App Term Term
    deriving (Eq,Show,Read)

fv :: Term -> Set.Set Var
fv (Var v)   = Set.singleton v
fv (App t u) = fv t `Set.union` fv u
fv (Lam v t) = Set.delete v (fv t)

showTerm :: Term -> String
showTerm (Var v)     = v
showTerm (Lam v t)   = "\\" ++ v ++ f t
    where f (Lam v t) = " " ++ v ++ f t
          f t = ". " ++ showTerm t
showTerm (App t1 t2) = f t1 ++ " " ++ g t2
    where f t@(App _ _) = showTerm t
          f t = g t
          g (Var v) = v
          g t = "(" ++ showTerm t ++ ")"

-- ---------------------------------------------------------------------------
-- Semantics

-- Operational semantics
oper :: Term -> [Term]
oper t = t : unfoldr (fmap fork . trans) t
    where fork x = (x,x)

-- One-step operational semantics
trans :: Term -> Maybe Term
trans (App (Lam v t1) t2) = return (beta v t1 t2)
trans (App t1 t2) = 
    (do t1' <- trans t1; return (App t1' t2)) `mplus`
    (do t2' <- trans t2; return (App t1 t2'))
trans (Lam v t) =
    do t <- trans t
       return (Lam v t)
trans _ = mzero

-- (\v.t1) t2 ==> t1[v := t2]
beta :: Var -> Term -> Term -> Term
beta v t1 t2 = f (alpha (fv t2) t1)
    where f (App a b) = App (f a) (f b)
          f x@(Var v1)
              | v==v1     = t2
              | otherwise = x
          f x@(Lam v1 body)
              | v==v1     = x
              | otherwise = Lam v1 (f body)

-- vs���ѿ���«�����ʤ��褦��t����Ѵ�
alpha :: Set.Set Var -> Term -> Term
alpha vs t = f Map.empty (vs `Set.union` fv t) t
    where f s xs (App a b)    = App (f s xs a) (f s xs b)
          f s xs (Var v)      = Var (fromMaybe v (Map.lookup v s))
          f s xs (Lam v body) = Lam v' (f s' xs' body)
              where v' | v `Set.member` xs = gensym xs v
                       | otherwise         = v
                    xs' = Set.insert v (Set.insert v' xs)
                    s'  = Map.insert v v' s

gensym :: Set.Set Var -> Var -> Var
gensym vs v = fromJust $ find (not . (`Set.member` vs))
                              [v ++ "_" ++ show i | i <- [1..]]

-- ---------------------------------------------------------------------------

lambdas :: [Var] -> Term -> Term
lambdas vs t = foldr Lam t vs

add, mul, exp :: Term
add = lambdas ["a","b","f","x"] $
        Var "a" <@> Var "f" <@> (Var "b" <@> Var "f" <@> Var "x")
mul = lambdas ["a","b","f"] $ Var "a" <@> (Var "b" <@> Var "f")
exp = lambdas ["a","b"] $ Var "b" <@> Var "a"
pred = lambdas ["n","s","z"] $
       Var "n" <@> (lambdas ["g","h"] $ Var "h" <@> (Var "g" <@> Var "s"))
               <@> (Lam "_" $ Var "z")
               <@> (Lam "u" $ Var "u")
sub = lambdas ["a","b"] $ Var "b" <@> pred <@> Var "a"

numToTerm :: Integer -> Term
numToTerm n = Lam "f" $ Lam "x" $ f n
    where f 0     = Var "x"
          f (n+1) = App (Var "f") (f n)

-- ---------------------------------------------------------------------------
-- Monadic Parser Combinator Library

newtype Parser tok a = Parser{ runParser :: [tok] -> Maybe (a,[tok]) }

instance Monad (Parser tok) where
    return x = Parser (\s -> Just (x,s))
    m >>= f = Parser (\s -> do (x,s') <- runParser m s
                               runParser (f x) s')
    fail _ = mzero

(<|>) :: Parser tok a -> Parser tok a -> Parser tok a
p1 <|> p2 = Parser (\s -> runParser p1 s `mplus` runParser p2 s)

instance MonadPlus (Parser tok) where
    mzero = Parser (\_ -> Nothing)
    mplus = (<|>)

anyToken :: Parser tok tok
anyToken = Parser f
    where f (x:xs) = Just (x,xs)
          f _      = Nothing

token :: Eq tok => tok -> Parser tok ()
token c =
    do x <- anyToken
       guard (c==x)
       return ()

many :: Parser tok a -> Parser tok [a]
many p = many1 p <|> return []

many1 :: Parser tok a -> Parser tok [a]
many1 p = do x  <- p
             xs <- many p
             return (x:xs)

-- ---------------------------------------------------------------------------
-- Parser

data Token
    = TokLambda
    | TokDot
    | TokLParen
    | TokRParen
    | TokIdent String
    | TokNumber Integer
    | TokAdd
    | TokSub
    | TokMul
    | TokExp
    deriving (Eq,Show,Read)

lex :: String -> [Token]
lex = lex' . dropWhile isSpace

lex' :: String -> [Token]
lex' [] = []
lex' ('\\' : xs) = TokLambda : lex xs
lex' ('.' : xs)  = TokDot    : lex xs
lex' ('-' : '>' : xs) = TokDot : lex xs -- Haskell�Ȥθߴ���(?)�Τ���
lex' ('(' : xs)  = TokLParen : lex xs
lex' (')' : xs)  = TokRParen : lex xs
lex' ('+' : xs)  = TokAdd    : lex xs
lex' ('*' : xs)  = TokMul    : lex xs
lex' ('^' : xs)  = TokExp    : lex xs
lex' ('-' : xs)  = TokSub    : lex xs
lex' xs@(x : _)
   | isDigit x =
       case span isDigit xs of
       (ys,zs) -> TokNumber (read ys) : lex zs
   | otherwise =
       case span f xs of
       (ys,zs) -> TokIdent ys : lex zs
   where f c = c=='_' || isAlphaNum c

ident :: Parser Token String
ident =
    do t <- anyToken
       case t of
        TokIdent s -> return s
        _ -> mzero

number :: Parser Token Integer
number =
    do t <- anyToken
       case t of
        TokNumber n -> return n
        _ -> mzero

term :: Parser Token Term
term = abs <|> expr
    where abs =
              do token TokLambda
                 vs <- many1 ident
                 token TokDot
                 t <- term
                 return (foldr Lam t vs)
          expr = foldr phi expr' ops
              where ops = [ (token TokAdd >> return add) <|>
                            (token TokSub >> return sub)
                          , token TokMul >> return mul
                          , token TokExp >> return exp
                          ]
                    phi op sub =
                        do t  <- sub
                           xs <- many $ do o <- op
                                           x <- sub
                                           return (o,x)
                           return (foldl (\t1 (op,t2) -> op <@> t1 <@> t2) t xs)
          expr' = do (t:ts) <- many1 p
                     return (foldl (<@>) t ts)
              where p =  liftM Var ident
                     <|> liftM numToTerm number
                     <|> parenthesize term

parenthesize :: Parser Token a -> Parser Token a
parenthesize p =
    do token TokLParen
       x <- p
       token TokRParen
       return x

-- ---------------------------------------------------------------------------
-- Main

main :: IO ()
main =
    do putStr "> "
       l <- getLine
       case l of
         "exit" -> return ()
         _ ->
             do case runParser term (lex l) of
                  Just (t,[]) -> mapM_ (putStrLn . showTerm) (oper t)
                  _           -> putStrLn "<parse error>"
                main


{-
�¹���:

> 5+6
(\a b f x. a f (b f x)) (\f x. f (f (f (f (f x))))) (\f x. f (f (f (f (f (f x))))))
(\b f x. (\f x. f (f (f (f (f x))))) f (b f x)) (\f x. f (f (f (f (f (f x))))))
\f x. (\f x. f (f (f (f (f x))))) f ((\f x. f (f (f (f (f (f x)))))) f x)
\f x. (\x. f (f (f (f (f x))))) ((\f x. f (f (f (f (f (f x)))))) f x)
\f x. f (f (f (f (f ((\f x. f (f (f (f (f (f x)))))) f x)))))
\f x. f (f (f (f (f ((\x. f (f (f (f (f (f x)))))) x)))))
\f x. f (f (f (f (f (f (f (f (f (f (f x))))))))))
> 2*5
(\a b f. a (b f)) (\f x. f (f x)) (\f x. f (f (f (f (f x)))))
(\b f. (\f x. f (f x)) (b f)) (\f x. f (f (f (f (f x)))))
\f. (\f x. f (f x)) ((\f x. f (f (f (f (f x))))) f)
\f x. (\f x. f (f (f (f (f x))))) f ((\f x. f (f (f (f (f x))))) f x)
\f x. (\x. f (f (f (f (f x))))) ((\f x. f (f (f (f (f x))))) f x)
\f x. f (f (f (f (f ((\f x. f (f (f (f (f x))))) f x)))))
\f x. f (f (f (f (f ((\x. f (f (f (f (f x))))) x)))))
\f x. f (f (f (f (f (f (f (f (f (f x)))))))))
> 2 ^ 3
(\a b. b a) (\f x. f (f x)) (\f x. f (f (f x)))
(\b. b (\f x. f (f x))) (\f x. f (f (f x)))
(\f x. f (f (f x))) (\f x. f (f x))
\x. (\f x. f (f x)) ((\f x. f (f x)) ((\f x. f (f x)) x))
\x x_1. (\f x. f (f x)) ((\f x. f (f x)) x) ((\f x. f (f x)) ((\f x. f (f x)) x) x_1)
\x x_1. (\x_1. (\f x. f (f x)) x ((\f x. f (f x)) x x_1)) ((\f x. f (f x)) ((\f x. f (f x)) x) x_1)
\x x_1. (\f x_2. f (f x_2)) x ((\f x_2. f (f x_2)) x ((\f x. f (f x)) ((\f x. f (f x)) x) x_1))
\x x_1. (\x_2. x (x x_2)) ((\f x_2. f (f x_2)) x ((\f x. f (f x)) ((\f x. f (f x)) x) x_1))
\x x_1. x (x ((\f x_2. f (f x_2)) x ((\f x. f (f x)) ((\f x. f (f x)) x) x_1)))
\x x_1. x (x ((\x_2. x (x x_2)) ((\f x. f (f x)) ((\f x. f (f x)) x) x_1)))
\x x_1. x (x (x (x ((\f x. f (f x)) ((\f x. f (f x)) x) x_1))))
\x x_1. x (x (x (x ((\x_1. (\f x. f (f x)) x ((\f x. f (f x)) x x_1)) x_1))))
\x x_1. x (x (x (x ((\f x. f (f x)) x ((\f x. f (f x)) x x_1)))))
\x x_1. x (x (x (x ((\x_1. x (x x_1)) ((\f x. f (f x)) x x_1)))))
\x x_1. x (x (x (x (x (x ((\f x. f (f x)) x x_1))))))
\x x_1. x (x (x (x (x (x ((\x_1. x (x x_1)) x_1))))))
\x x_1. x (x (x (x (x (x (x (x x_1)))))))

-}
