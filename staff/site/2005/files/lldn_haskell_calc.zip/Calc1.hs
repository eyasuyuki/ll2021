{-# OPTIONS -fglasgow-exts #-}
module Main where

import Control.Monad
import Data.Ratio
import Data.Maybe (fromMaybe)

-- ---------------------------------------------------------------------------
-- Monadic Parser Combinator Library

newtype Parser a = Parser{ runParser :: String -> Maybe (a,String) }

instance Monad Parser where
    return x = Parser (\s -> Just (x,s))
    m >>= f = Parser (\s -> do (x,s') <- runParser m s
                               runParser (f x) s')
    fail _ = mzero

(<|>) :: Parser a -> Parser a -> Parser a
p1 <|> p2 = Parser (\s -> runParser p1 s `mplus` runParser p2 s)

instance MonadPlus Parser where
    mzero = Parser (\_ -> Nothing)
    mplus = (<|>)

anyChar :: Parser Char
anyChar = Parser f
    where f (x:xs) = Just (x,xs)
          f _      = Nothing

char :: Char -> Parser ()
char c =
    do x <- anyChar
       guard (c==x)
       return ()

string :: String -> Parser ()
string s = mapM_ char s

many :: Parser a -> Parser [a]
many p = many1 p <|> return []

many1 :: Parser a -> Parser [a]
many1 p = do x  <- p
             xs <- many p
             return (x:xs)

-- --------------------------------------------------------------------------
-- Syntactic Domain

data Expr
    = Number Integer
    | BinOpApp BinOp Expr Expr
    deriving (Eq,Show,Read)

data BinOp = Add | Sub | Mul | Div deriving (Eq,Show,Read)

-- --------------------------------------------------------------------------
-- Parser

digits :: [(String, Integer)]
digits =
    [ ("��", 0)
    , ("��", 1)
    , ("��", 2)
    , ("��", 3)
    , ("��", 4)
    , ("��", 5)
    , ("ϻ", 6)
    , ("��", 7)
    , ("Ȭ", 8)
    , ("��", 9)
    ]

digit :: Parser Integer
digit = msum [ string s >> return x | (s,x) <- digits ]

units :: [(String, Integer)]
units =
    [ ("̵�����", 10 ^ 88)
    , ("�ԲĻ׵�", 10 ^ 80)
    , ("��ͳ¿",   10 ^ 72)
    , ("���ε�",   10 ^ 64)
    , ("���Ϻ�",   10 ^ 56)
    , ("��",       10 ^ 48)
    , ("��",       10 ^ 44)
    , ("��",       10 ^ 40)
    , ("��",       10 ^ 36)
    , ("��",       10 ^ 32)
    , ("��",       10 ^ 28)
    , ("��ͽ",     10 ^ 24)
    , ("Զ",       10 ^ 20)
    , ("��",       10 ^ 16)
    , ("��",       10 ^ 12)
    , ("��",       10 ^  8)
    , ("��",       10 ^  4)
    , ("��",       10 ^  3)
    , ("ɴ",       10 ^  2)
    , ("��",       10 ^  1)
    ]

number :: Parser Integer
number = do x <- number' units
            case x of
              Just y  -> return y
              Nothing -> mzero

number' :: [(String, Integer)] -> Parser (Maybe Integer)
number' [] = liftM Just digit <|> return Nothing
number' ((s,u) : us) =
    do x <- number' us
       let p = do string s
                  y <- number' us
                  return (Just (fromMaybe 1 x * u + fromMaybe 0 y))
       p <|> return x

-----------------------------------------------------------------------------

-- genExpr(sub,op) ::= sub (op sub)*
genExpr :: Parser Expr -> Parser BinOp -> Parser Expr
genExpr sub op =
    do e  <- sub
       xs <- many p
       return (foldl (\a (o,b) -> BinOpApp o a b) e xs)
    where p = do o <- op
                 x <- sub
                 return (o,x)

-- expr ::= term (('��'|'�ݡ�) term)*
expr :: Parser Expr
expr = genExpr term op
    where op =  (string "��" >> return Add)
            <|> (string "��" >> return Sub)

-- term ::= factor (('��'|'���) factor)*
term :: Parser Expr
term = genExpr factor op
    where op =  (string "��" >> return Mul)
            <|> (string "��" >> return Div)

-- factor ::= '��' expr '��' | number
factor :: Parser Expr
factor = parenthesize expr
      <|> do x <- number
             return (Number x)

parenthesize :: Parser a -> Parser a
parenthesize p =
    do string "��"
       x <- p
       string "��"
       return x

-- --------------------------------------------------------------------------
-- Semantic Domain

type Value = Maybe Rational

instance Num Value where
    (+)         = liftM2 (+)
    (*)         = liftM2 (*)
    (-)         = liftM2 (-)
    negate      = liftM negate
    abs         = liftM abs
    signum      = liftM signum
    fromInteger = Just . fromInteger

instance Fractional Value where
    _ / 0 = Nothing
    a / b = liftM2 (/) a b
    fromRational = Just

-- --------------------------------------------------------------------------
-- Denotational Semantics

eval :: Expr -> Value
eval (Number x)        = fromIntegral x
eval (BinOpApp op a b) = evalBinOp op (eval a) (eval b)

evalBinOp :: BinOp -> (Value -> Value -> Value)
evalBinOp Add = (+)
evalBinOp Sub = (-)
evalBinOp Mul = (*)
evalBinOp Div = (/)

-- --------------------------------------------------------------------------
--  Printing

showValue :: Value -> String
showValue Nothing  = "<undefined>"
showValue (Just x) = showRational x

showRational :: Rational -> String
showRational x
    | denominator x == 1 = showInteger (numerator x)
    | otherwise =
        showInteger (numerator x `div` denominator x) ++ ";"

showInteger :: Integer -> String
showInteger x
    | x == 0    = "��"
    | x < 0     = "��" ++ f units (-x)
    | otherwise = f units x
    where f ((s,u):us) x =
              case x `divMod` u of
              (y,z) | y==0 -> f us z
                    | y==1 && (u `elem` [10,100,1000]) -> s ++ f us z
                    | otherwise -> f us y ++ s ++ f us z
          f [] x = table !! fromIntegral x
          table = ["","��","��","��","��","��","ϻ","��","Ȭ","��"]

-- --------------------------------------------------------------------------
-- Main

main :: IO ()
main =
    do putStr "> "
       l <- getLine
       case l of
         "exit" -> return ()
         _ ->
             do case runParser expr l of
                  Just (e,[]) -> putStrLn (showValue (eval e))
                  _           -> putStrLn "<parse error>"
                main
