ActionController::Routing::Routes.draw do |map|
  map.connect '/tags/*tags', :controller => 'journals', :action => 'tags'
  map.connect '/account_titles/:action/:id', :controller => 'account_titles'
  map.connect '/:action/:id', :controller => 'journals'
  map.connect '/', :controller => 'journals', :action => 'list'
end
