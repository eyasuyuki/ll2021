# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  def tdiary_like_navigate
    months = Journal.months

    current = months.blank? ? Date.new(Date.today.year, Date.today.month) : months.first
    today = Date.today

    results = {}

    while current <= today
      year = (results[current.year] ||= [])
      year << current
      current = current >> 1
    end

    results.inject('') do |r, hash|
      key, value = hash
      r << "<br>#{link_to(key, :controller => 'journals', :action => 'tags', :tags => key)} | "
      value.each do |month|
        r << link_to_if(months.include?(month), month.strftime('%m'), :controller => 'journals', :action => 'tags', :tags => month.strftime('%Y-%m'))
        r << ' | '
      end
      r
    end
  end
end
