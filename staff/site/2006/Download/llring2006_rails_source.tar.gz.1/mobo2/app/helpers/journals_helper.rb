module JournalsHelper
  def tagnize(text = nil)
    text.to_s.split(/[\s　]+/).map do |t|
        link_to(t, :controller => 'journals', :action => 'tags', :tags => t)
    end.join ' '
  end
end
