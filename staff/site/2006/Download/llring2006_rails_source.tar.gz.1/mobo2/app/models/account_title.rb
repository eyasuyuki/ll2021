# == Schema Information
# Schema version: 4
#
# Table name: account_titles
#
#  id           :integer       not null, primary key
#  name         :string(255)   
#  account_type :integer       
#

# account_type:
#  0 => "資産科目群",
#  1 => "負債・資本科目群",
#  2 => "費用科目群",
#  3 => "収益科目群",

class AccountTitle < ActiveRecord::Base
validates_presence_of :name
validates_presence_of :account_type

 
 def self.expenses
    self.find_all_by_account_type(2)
  end

  def self.assets
    self.find_all_by_account_type(0)
  end

  def remain
    Journal.sum(:amount, :conditions => ["debtor_id = ?", self.id]).to_i -
      Journal.sum(:amount, :conditions => ["creditor_id = ?", self.id]).to_i
  end
end
