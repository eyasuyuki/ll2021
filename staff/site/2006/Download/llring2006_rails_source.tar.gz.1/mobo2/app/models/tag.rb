class Tag < ActiveRecord::Base
end
