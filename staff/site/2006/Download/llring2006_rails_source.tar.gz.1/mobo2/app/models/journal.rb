# == Schema Information
# Schema version: 4
#
# Table name: journals
#
#  id          :integer       not null, primary key
#  date        :date          
#  amount      :integer       
#  debtor_id   :integer       
#  creditor_id :integer       
#  text        :text          
#

class Journal < ActiveRecord::Base
  acts_as_taggable

  set_field_names :amount => '金額', :text => 'メモ'
  belongs_to :debtor, :class_name => "AccountTitle", :foreign_key => :debtor_id
  belongs_to :creditor, :class_name => "AccountTitle", :foreign_key => :creditor_id
  validates_numericality_of :amount

  def before_save
    self.tag self.text, :clear => true, :separator => /[\s　]/
    self.tag self.date.strftime("%Y %Y-%m %Y-%m-%d")
    self.tag self.debtor.name
    self.tag self.creditor.name
  end

  def self.months
    self.find(:all, :select => 'date', :group => 'date').map do |ar|
      Date.new ar.date.year, ar.date.month
    end.uniq.sort
  end
end
