class JournalsController < ApplicationController
  GRAPH_WIDTH = 600
  GRAPH_FONT = File.expand_path("font/ipagp.ttf", RAILS_ROOT)

  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def tags
    list
    render :action => 'list'
  end

  def tags_redirect
    redirect_to :action => 'tags', :tags => params[:tags].split(/[\s　]+/)
  end

  def list
    prepare_journals
    set_account_titles
    @journal = Journal.new
  end

  def show
    @journal = Journal.find(params[:id])
  end

  def new
    @journal = Journal.new
  end

  def create
    @journal = Journal.new(params[:journal])
    if @journal.save
      flash[:notice] = 'Journal was successfully created.'
      redirect_to :action => 'list'
    else
      list
      render :action => 'list'
    end
  end

  def edit
    prepare_journals
    set_account_titles
    @journal = Journal.find(params[:id])
  end

  def update
    @journal = Journal.find(params[:id])
    if @journal.update_attributes(params[:journal])
      flash[:notice] = 'Journal was successfully updated.'
      redirect_to :action => 'show', :id => @journal
    else
      render :action => 'edit'
    end
  end

  def destroy
    Journal.find(params[:id]).destroy
    redirect_to :action => 'list'
  end

  def graph_assets
    g = Gruff::Pie.new(GRAPH_WIDTH)
    g.font = GRAPH_FONT
    g.title = "家計簿グラフ"

    for title in AccountTitle.assets
      g.data(title.name, [title.remain])
    end

    g.labels = {0 => '2004', 2 => '2005', 4 => '2006'}

    send_data(g.to_blob, :disposition => 'inline', :type => 'image/png', :filename => "gruff.png")
  end

  def graph_expenses
    prepare_journals
    g = Gruff::Pie.new(GRAPH_WIDTH)
    g.font = GRAPH_FONT
    g.title = "家計簿グラフ"

    for title in AccountTitle.expenses
      g.data(title.name, [@journals.select{|e| e.debtor_id == title.id}.inject(0){|s, e| s + e.amount} - @journals.select{|e| e.creditor == title.id}.inject(0){|s, e| s + e.amount}])
    end

    send_data(g.to_blob, :disposition => 'inline', :type => 'image/png', :filename => "gruff.png")
  end

  private

  def prepare_journals
    conditions = nil

    tags = params[:tags]
    unless tags.blank?
      ids = Journal.find_tagged_with(:all => tags).collect(&:id)
      conditions = ['journals.id in (?)', ids]
    end

    @journal_pages, @journals = paginate :journals, :conditions => conditions,:include => [:debtor, :creditor], :per_page => 100, :order => :date
  end

  def set_account_titles
    @account_titles = AccountTitle.find_all.collect do |e|
      [e.name, e.id]
    end
  end
end
