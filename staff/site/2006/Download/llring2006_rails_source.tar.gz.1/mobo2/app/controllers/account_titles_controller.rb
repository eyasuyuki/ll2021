class AccountTitlesController < ApplicationController
ACCOUNT_TYPES={
    0=>"資産科目群",
    1=>"負債・資本科目群",
    2=>"費用科目群",
    3=>"収益科目群"
  }

  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @account_title_pages, @account_titles = paginate :account_titles, :per_page => 100
    @account_title = AccountTitle.new
  end

  def create
    @account_title = AccountTitle.new(params[:account_title])
    if @account_title.save
      flash[:notice] = 'AccountTitle was successfully created.'
      redirect_to :action => 'list'
    else
      @account_title_pages, @account_titles = paginate :account_titles, :per_page => 100
      render :action => 'list'
    end
  end

  def edit
    @account_title = AccountTitle.find(params[:id])
  end

  def update
    @account_title = AccountTitle.find(params[:id])
    if @account_title.update_attributes(params[:account_title])
      flash[:notice] = 'AccountTitle was successfully updated.'
      redirect_to :action => 'list'
    else
      render :action => 'edit'
    end
  end

  def destroy
    AccountTitle.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
