class CreateJournals < ActiveRecord::Migration
  def self.up
    create_table(:journals) do |t|
      t.column(:date, :date)
      t.column(:amount, :integer)
      t.column(:debtor_id, :integer)
      t.column(:creditor_id, :integer)
      t.column(:text, :text)
    end
  end

  def self.down
    drop_table(:journals)
  end
end
