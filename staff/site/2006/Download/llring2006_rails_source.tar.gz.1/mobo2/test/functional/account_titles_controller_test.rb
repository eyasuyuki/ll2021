require File.dirname(__FILE__) + '/../test_helper'
require 'account_titles_controller'

# Re-raise errors caught by the controller.
class AccountTitlesController; def rescue_action(e) raise e end; end

class AccountTitlesControllerTest < Test::Unit::TestCase
  fixtures :account_titles

  def setup
    @controller = AccountTitlesController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_index
    get :index
    assert_response :success
    assert_template 'list'
  end

  def test_list
    get :list

    assert_response :success
    assert_template 'list'

    assert_not_nil assigns(:account_titles)
  end

  def test_create
    num_account_titles = AccountTitle.count

    post :create, :account_title => {:name=>"foo", :account_type=>1}

    assert_response :redirect
    assert_redirected_to :action => 'list'

    assert_equal num_account_titles + 1, AccountTitle.count
  end

  def test_edit
    get :edit, :id => 1

    assert_response :success
    assert_template 'edit'

    assert_not_nil assigns(:account_title)
    assert assigns(:account_title).valid?
  end

  def test_update
    post :update, :id => 1
    assert_response :redirect
    assert_redirected_to :action => 'list'
  end

  def test_destroy
    assert_not_nil AccountTitle.find(1)

    post :destroy, :id => 1
    assert_response :redirect
    assert_redirected_to :action => 'list'

    assert_raise(ActiveRecord::RecordNotFound) {
      AccountTitle.find(1)
    }
  end
end
