require File.dirname(__FILE__) + '/../test_helper'

class AccountTitleTest < Test::Unit::TestCase
  fixtures :account_titles, :journals

  def test_remain
    assert_equal(7000, account_titles(:saifu).remain)
    assert_equal(100000, account_titles(:ginko).remain)
  end
end
