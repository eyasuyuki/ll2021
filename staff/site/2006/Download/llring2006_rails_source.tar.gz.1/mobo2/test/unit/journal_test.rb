require File.dirname(__FILE__) + '/../test_helper'

class JournalTest < Test::Unit::TestCase
  fixtures :journals

  def test_tags
    journal = Journal.new(:date => Date.new(2006, 1, 2),
                          :amount => 1000,
                          :debtor_id => 1,
                          :creditor_id => 1,
                          :text => "foo bar")
    journal.save
    assert_equal(["foo", "bar", "2006", "2006-01", "2006-01-02", "財布"].sort,
                 journal.tag_names.sort)
  end
end
